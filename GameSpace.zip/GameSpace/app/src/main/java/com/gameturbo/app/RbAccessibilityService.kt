package com.gameturbo.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent

/** Dipakai hanya untuk mengambil screenshot dari tombol di panel. Tidak membaca isi layar. */
class RbAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    fun tap(x: Float, y: Float) {
        try {
            val p = android.graphics.Path().apply { moveTo(x, y) }
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(p, 0, 30)).build()
            dispatchGesture(g, null, null)
        } catch (_: Exception) {}
    }

    fun shoot(done: (Boolean) -> Unit) {
        if (Build.VERSION.SDK_INT >= 30) {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                    var ok = false
                    try {
                        val hb = r.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                        if (hw != null) {
                            val sw = hw.copy(Bitmap.Config.ARGB_8888, false)
                            ok = Sys.savePng(applicationContext, sw)
                        }
                        hb.close()
                    } catch (e: Exception) {
                        ok = false
                    }
                    done(ok)
                }

                override fun onFailure(errorCode: Int) {
                    done(false)
                }
            })
        } else if (Build.VERSION.SDK_INT >= 28) {
            done(performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT))
        } else {
            done(false)
        }
    }

    companion object {
        @Volatile
        var inst: RbAccessibilityService? = null
    }
}
