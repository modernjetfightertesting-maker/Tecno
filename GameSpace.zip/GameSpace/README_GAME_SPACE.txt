GAME SPACE (GT Boost) - app Android
1. Upload GameSpace.zip ke repo GitHub (hapus zip lain agar tidak tertukar; build.yml memakai zip TERBARU).
2. Actions -> build -> unduh APK dari artifact -> install.
3. Buka app: setujui welcome, izinkan "tampil di atas aplikasi lain", lalu ketuk ikon game.
Mode: Power Saving (ungu-biru), Balanced (hijau), GT Boost (merah).
